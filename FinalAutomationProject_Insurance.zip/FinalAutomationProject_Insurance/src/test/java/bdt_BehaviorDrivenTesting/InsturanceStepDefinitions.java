package bdt_BehaviorDrivenTesting;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom_ap_PACKAGE.POM_Demoguru_Login;

public class InsturanceStepDefinitions 
{
	WebDriver driver;
	POM_Demoguru_Login p;

	@Given("I am on the login page")
	public void i_am_on_the_login_page() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		driver = new ChromeDriver();
		p = new POM_Demoguru_Login();
		p.openexactpage(driver);
	}

	@When("I enter email {string} and password {string}")
	public void i_enter_email_and_password(String email, String password) throws Exception 
	{
		driver.findElement(By.name("email")).sendKeys(email);
		Thread.sleep(1000);

		driver.findElement(By.id("password")).sendKeys(password);
		Thread.sleep(1000);

	}

	@When("I click on the login button")
	public void i_click_on_the_login_button() throws InterruptedException 
	{
		driver.findElement(By.name("submit")).click();
		Thread.sleep(1000);

	}

	@Then("I close the browser")
	public void i_close_the_browser() throws InterruptedException 
	{
		driver.findElement(By.cssSelector(".btn.btn-danger")).click();
		driver.close();
	}
}