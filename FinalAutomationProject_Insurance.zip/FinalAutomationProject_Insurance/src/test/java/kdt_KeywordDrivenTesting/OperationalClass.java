package kdt_KeywordDrivenTesting;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OperationalClass {

    public void maximizeBrowser(WebDriver driver) {
        driver.manage().window().maximize();
    }

    public void deleteAllCookies(WebDriver driver) {
        driver.manage().deleteAllCookies();
    }

    public void implicitWait(WebDriver driver) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    }

    public void url(WebDriver driver) 
    {
		driver.get("https://demo.guru99.com/insurance/v1/index.php");
    }

    public void email(WebDriver driver, String email) throws InterruptedException {
    	driver.findElement(By.name("email")).sendKeys(email); Thread.sleep(1000);
    }

    public void password(WebDriver driver, String pswd) throws InterruptedException {
		driver.findElement(By.id("password")).sendKeys(pswd);Thread.sleep(1000);
    }

    public void loginButton(WebDriver driver) throws Exception {
		driver.findElement(By.name("submit")).click();Thread.sleep(1000);	
    }

    
    public void logout(WebDriver driver) {
		driver.findElement(By.cssSelector(".btn.btn-danger")).click();
    }

    public void closeBrowser(WebDriver driver) {
        driver.close();
    }
}
