package kdt_KeywordDrivenTesting;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcelClass 
{
	public void readExcelsub(WebDriver driver)throws Exception
	{
	// STEP 1: Create an object to store the Excel file path
    FileInputStream file = new FileInputStream("C:\\Users\\ganes\\OneDrive\\Desktop\\AP.xlsx");

    // STEP 2: Create an object for the workbook
    XSSFWorkbook w = new XSSFWorkbook(file);

    // STEP 3: Create an object for the sheet ("KDT") using the workbook object
    XSSFSheet s = w.getSheet("KDT");

	int size=s.getLastRowNum(); 
	OperationalClass o=new OperationalClass();
	System.out.println("no of keys"+size);
	for(int i=1;i<=size;i++)
	{
		String key=s.getRow(i).getCell(0).getStringCellValue(); 
		System.out.println(key);

		//Execute process as per the Excel Sheet keywords with Operational Class methods: Conditional Statements 
		if(key.equals("Maximize Browser"))

		{ 
			o.maximizeBrowser(driver);

		} 
		else if(key.equals("Delete All Cookies"))

		{
			o.deleteAllCookies(driver);

		}
		else if(key.equals("Enter URL"))
		{
			o.url(driver);
			Thread.sleep(2000);
		}
		else if(key.equals("Enter Email"))
		{ 
			o.email(driver,"nivi@gmail.com");
		} 
		else if(key.equals("Enter Password"))
		{
			o.password(driver,"Admin123@");
		} 
		else if(key.equals("Click On Login Button"))
		{
			o.loginButton(driver);
			Thread.sleep(200);
		}	
		
		else if(key.equals("Click On Logout Button"))
		{
			o.logout(driver);
		}
		else if(key.equals("Close Browser"))
		{
			o.closeBrowser(driver);
		}
		w.close();
	}
		
	//Store keywords in variables

	}
}


