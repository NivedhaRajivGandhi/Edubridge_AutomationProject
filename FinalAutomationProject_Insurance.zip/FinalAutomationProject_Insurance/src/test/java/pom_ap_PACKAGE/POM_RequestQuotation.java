package pom_ap_PACKAGE;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class POM_RequestQuotation {
    
WebDriver driver;
    public void Req_Quotationrr(WebDriver driver) throws InterruptedException
    {
    	selectOptionByValue("quotation_breakdowncover", "2"); // Select breakdown cover option
		driver.findElement(By.id("quotation_windscreenrepair_t")).click(); // Click windscreen repair option
		driver.findElement(By.id("quotation_incidents")).sendKeys("2331"); // Fill in incident count
		driver.findElement(By.id("quotation_vehicle_attributes_registration")).sendKeys("DL1AB1234"); // Fill in vehicle registration
		driver.findElement(By.id("quotation_vehicle_attributes_mileage")).sendKeys("20,000"); // Fill in mileage
		driver.findElement(By.id("quotation_vehicle_attributes_value")).sendKeys("692000"); // Fill in vehicle value
		selectOptionByValue("quotation_vehicle_attributes_parkinglocation", "Public place"); // Select parking location
		selectOptionByValue("quotation_vehicle_attributes_policystart_1i", "2024"); // Select policy start year
		selectOptionByValue("quotation_vehicle_attributes_policystart_2i", "3"); // Select policy start month
		selectOptionByValue("quotation_vehicle_attributes_policystart_3i", "23"); // Select policy start day
		driver.findElement(By.cssSelector("input.btn.btn-default")).click(); // Calculate premium
		Thread.sleep(2000); // Wait for calculation
		driver.findElement(By.cssSelector("input.btn.btn-success")).click(); // Save quotation
		Thread.sleep(10000); // Wait for saving
		driver.navigate().back();	// Navigate back
		Thread.sleep(2000); // Wait for page load
		driver.findElement(By.id("ui-id-2")).click(); // Navigate to quotation section again
		Thread.sleep(2000); // Wait for page load
		driver.findElement(By.id("resetquote")).click(); // Reset quotation form
		Thread.sleep(2000); // Wait for action completion
		}

 // Method to select dropdown option by value
 	private void selectOptionByValue(String elementId, String value) throws InterruptedException 
 	{
 		Select dropdown = new Select(driver.findElement(By.id(elementId))); // Initialize Select object
 		Thread.sleep(1000); // Wait for element visibility
 		dropdown.selectByValue(value); // Select option by value
 		Thread.sleep(2000); // Wait for action completion
 	}

	public void Retrive_Quotation(WebDriver driver)
	{
			
			driver.findElement(By.name("id")).sendKeys("");
			driver.findElement(By.id("getquote")).click();
	}
	public void selectDropDown(String elementId, String value) throws InterruptedException 
	{
	        Select dropdown = new Select(driver.findElement(By.id(elementId)));
	        Thread.sleep(1000);
	        dropdown.selectByValue(value);
	        Thread.sleep(2000);
    }
	public void scroll(WebDriver driver) 
	{
		// Create a JavaScriptExecutor instance
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Scroll to the bottom of the page smoothly
		js.executeScript("window.scrollBy(0, document.body.scrollHeight/0.5)");

	}


}
