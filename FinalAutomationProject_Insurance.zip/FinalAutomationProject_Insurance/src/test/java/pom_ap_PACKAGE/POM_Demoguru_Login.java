package pom_ap_PACKAGE;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class POM_Demoguru_Login {
	WebDriver driver;

	public void LoginCredentials(WebDriver driver) throws Exception {
		driver.findElement(By.name("email")).sendKeys("nivigu@gmail.com");
		Thread.sleep(1000);

		driver.findElement(By.id("password")).sendKeys("Admin123@");
		Thread.sleep(1000);

		driver.findElement(By.name("submit")).click();
		Thread.sleep(1000);
	}

	public void Loginddt(WebDriver driver, String email, String pswd) throws Exception {
		driver.findElement(By.name("email")).sendKeys(email);
		Thread.sleep(1000);

		driver.findElement(By.id("password")).sendKeys(pswd);
		Thread.sleep(1000);

		driver.findElement(By.name("submit")).click();
		Thread.sleep(1000);
	}

	public void logout(WebDriver driver) throws InterruptedException {
		driver.findElement(By.cssSelector(".btn.btn-danger")).click();
	}

	public void closeBrowser(WebDriver driver) throws InterruptedException {
		driver.close();
	}

	public void openexactpage(WebDriver driver) throws InterruptedException {
		driver.get("https://demo.guru99.com/insurance/v1/index.php");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

//        // Locate and click the "Insurance Project" link
//        driver.findElement(By.linkText("Insurance Project")).click();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));

	}

	public void handleRegistration(WebDriver driver) throws InterruptedException 
	{
		// click on register button through xpath
		if (driver.getCurrentUrl().contains("https://demo.guru99.com/insurance/v1/header.php")) 
		{
			// If the URL contains "header.php", perform this action
			driver.findElement(By.id("ui-id-5")).click();

		} else {
			// If the URL doesn't contain "header.php", perform a different action
			driver.findElement(By.xpath("//a[text()='Register']")).click();
		}
		Thread.sleep(1000);

		// Sign up as a new user //DropDown >> TagName must be <Select>

		// Step 1: Create object Select class
		Select s;
		// locate the dropdown
		s = new Select(driver.findElement(By.id("user_title")));
		Thread.sleep(1000);
		// locate the value in the dropdown
		s.selectByValue("Mrs");
		Thread.sleep(2000);

		// firstname
		driver.findElement(By.id("user_firstname")).sendKeys("Nivedha");

		// surname
		driver.findElement(By.id("user_surname")).sendKeys("RajivGandhi");
		// phonenumber
		driver.findElement(By.id("user_phone")).sendKeys("6374529013");

		// date of birth year
		Select s2;
		s2 = new Select(driver.findElement(By.id("user_dateofbirth_1i")));
		Thread.sleep(1000);
		s2.selectByVisibleText("1995");
		Thread.sleep(2000);

		// month
		Select s3;
		s3 = new Select(driver.findElement(By.id("user_dateofbirth_2i")));
		Thread.sleep(1000);
		s3.selectByVisibleText("September");
		Thread.sleep(2000);

		// date
		Select s4;
		s4 = new Select(driver.findElement(By.id("user_dateofbirth_3i")));
		Thread.sleep(1000);
		s4.selectByValue("13");
		Thread.sleep(2000);

		if (driver.getCurrentUrl().contains("header.php")) {
			// If the URL contains "header.php", perform this action
			driver.findElement(By.id("user_licencetype_f")).click();
		} else {
			// If the URL doesn't contain "header.php", perform a different action
			driver.findElement(By.id("licencetype_f")).click();
		}

		// License period
		Select s5;
		s5 = new Select(driver.findElement(By.id("user_licenceperiod")));
		Thread.sleep(1000);
		s5.selectByVisibleText("10");
		Thread.sleep(2000);

		// occupation
		Select s6;
		s6 = new Select(driver.findElement(By.id("user_occupation_id")));
		Thread.sleep(1000);
		s6.selectByVisibleText("Artist");
		Thread.sleep(2000);

		// street
		driver.findElement(By.id("user_address_attributes_street")).sendKeys("kandhanchavadi");
		// city
		driver.findElement(By.id("user_address_attributes_city")).sendKeys("chennai");
		// country
		driver.findElement(By.id("user_address_attributes_county")).sendKeys("INDIA");
		// postalcode
		driver.findElement(By.id("user_address_attributes_postcode")).sendKeys("600096");
		// email

		if (driver.getCurrentUrl().contains("header.php")) 
		{
			// If the URL contains "header.php", perform this action
			driver.findElement(By.xpath("//input[@name='commit' and @value='Update User']")).click();

		} 
		else 
		{
			// If the URL doesn't contain "header.php", perform a different action

			driver.findElement(By.id("user_user_detail_attributes_email")).sendKeys("nivi12345@gmail.com");
			// password
			driver.findElement(By.id("user_user_detail_attributes_password")).sendKeys("Admin123@");
			// Confirm password
			driver.findElement(By.id("user_user_detail_attributes_password_confirmation")).sendKeys("Admin123@");
			Thread.sleep(2000);
			// driver.findElement(By.id("resetform")).click(); Thread.sleep(1000);
			driver.findElement(By.name("submit")).click();

			driver.findElement(By.id("email")).sendKeys("nivi12345@gmail.com");

			driver.findElement(By.id("password")).sendKeys("Admin123@");
			Thread.sleep(1000);
			driver.findElement(By.name("submit")).click();
			Thread.sleep(2000);

		}
	}

	public void scroll(WebDriver driver) {
		// Create a JavaScriptExecutor instance
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Scroll to the bottom of the page smoothly
		js.executeScript("window.scrollBy(0, document.body.scrollHeight/0.5)");

	}

	public void close() {
		driver.close();
		// TODO Auto-generated method stub

	}

}
