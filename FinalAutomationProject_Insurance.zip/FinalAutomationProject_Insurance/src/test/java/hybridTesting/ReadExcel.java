package hybridTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import kdt_KeywordDrivenTesting.OperationalClass;

public class ReadExcel {

    public void ReadExcelSub(WebDriver driver, String email, String pswd) throws Exception {
        // Create an object to store the Excel file path
        FileInputStream file = new FileInputStream("C:\\Users\\ganes\\OneDrive\\Desktop\\AP.xlsx");

        // Create an object for the workbook
        XSSFWorkbook w = new XSSFWorkbook(file);

        // Create an object for the sheet ("Hybrid") using the workbook object
        XSSFSheet s = w.getSheet("Hybrid");

        int size = s.getLastRowNum();
        OperationalClass o = new OperationalClass();

        // Iterate through each row in the Excel sheet
        for (int i = 1; i <= size; i++) {
            String email1 = s.getRow(i).getCell(0).getStringCellValue();
            String password = s.getRow(i).getCell(1).getStringCellValue();
            System.out.println(email1 + "\t\t" + password);

            // Iterate through each action in the Excel sheet
            for (int j = 1; j <= size; j++) {
                String key = s.getRow(j).getCell(2).getStringCellValue();

                try {
                    switch (key) {
                        case "Maximize Browser":
                            o.maximizeBrowser(driver);
                            break;
                        case "Delete All Cookies":
                            o.deleteAllCookies(driver);
                            break;
                        case "Enter URL":
                            o.url(driver);
                            Thread.sleep(2000);
                            break;
                        case "Enter Email":
                            o.email(driver, email1);
                            Thread.sleep(2000);
                            break;
                        case "Enter Password":
                            o.password(driver, password);
                            Thread.sleep(2000);
                            break;
                        case "Click On Login Button":
                            o.loginButton(driver);
                            Thread.sleep(200);
                            break;
                        case "Click On Logout Button":
                            o.logout(driver);
                            break;
                        case "Close Browser":
                            o.closeBrowser(driver);
                            break;
                        default:
                            break;
                    }

                    // If the execution reaches here, credentials are valid
                    System.out.println("Valid Credentials");
                    System.out.println("");
                    // Update Excel sheet with validation result
                    s.getRow(i).createCell(3).setCellValue("valid credentials");

                } catch (Exception e) {
                    // If any exception occurs, credentials are invalid
                    System.out.println("Invalid Credentials");
                    System.out.println("");
                    // Update Excel sheet with validation result
                    s.getRow(i).createCell(3).setCellValue("Invalid credentials");
                }
            }

            // Write changes to Excel file after processing each row
            FileOutputStream fo = new FileOutputStream("C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\POI\\POI1.xlsx");
            w.write(fo);
        }

        // Close browser after processing all rows
        o.closeBrowser(driver);
        // Close workbook and file streams
        w.close();
    }
}
