package hybridTesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass {

    public static void main(String[] args) {
        // Set system property for Chrome WebDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
        
        // Initialize ChromeDriver instance
        WebDriver driver = new ChromeDriver();
        
        // Create an instance of ReadExcel class
        ReadExcel r = new ReadExcel();
        
        try {
            // Call the ReadExcelSub method with WebDriver instance, email, and password
            r.ReadExcelSub(driver, "nivi@gmail.com", "Admin123@");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Quit the WebDriver instance
            if (driver != null) {
                driver.quit();
            }
        }
    }
}
