package basic_Functionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;
import java.util.Scanner;

public class CrossBrowser_Testing {

    // Method to select a web browser based on user input 
    public WebDriver WebDriver_selectBrowser() {
        WebDriver driver = null;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter 1 for Google Chrome.");
        System.out.println("Enter 2 for Mozilla Firefox.");
        System.out.println("Enter 3 for Microsoft Edge.");
        System.out.println("Enter 4 for Opera");
        int browserChoice = scanner.nextInt();

        switch (browserChoice) {
            case 1:
                System.out.println("You have chosen Google Chrome.");
                //WebDriverManager.chromedriver().setup();
                System.setProperty("webdriver.chrome.driver","C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
                driver = new ChromeDriver();
                break;
            case 2:
                System.out.println("You have chosen Mozilla Firefox.");
                System.setProperty("webdriver.gecko.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\geckodriver.exe");
                driver = new FirefoxDriver();
                break;
            case 3:
                System.out.println("You have chosen Microsoft Edge.");
                System.setProperty("webdriver.edge.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\msedgedriver.exe");
                driver = new EdgeDriver();
                break;
            case 4:
                System.out.println("You have chosen Opera.");
                System.setProperty("webdriver.edge.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\operadriver.exe");
                break;

            	
            default:
                System.out.println("Invalid choice. Please select 1, 2, or 3.");
                break;
        }

        return driver;
    }
}

