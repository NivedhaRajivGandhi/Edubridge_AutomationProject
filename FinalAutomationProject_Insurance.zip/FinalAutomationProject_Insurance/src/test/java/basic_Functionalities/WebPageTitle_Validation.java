package basic_Functionalities;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPageTitle_Validation {
    WebDriver driver;
    
    @Test
    public void PageTitleValidation() {

        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver","C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");

        // Initialize ChromeDriver
        driver = new ChromeDriver();

        // Navigate to the page you want to verify
        driver.get("https://demo.guru99.com/insurance/v1/index.php");

        // Example validation: Verify page title
        String expectedTitle = "https://demo.guru99.com/insurance/v1/index.php";
        String actualTitle = driver.getTitle();
        
        if(expectedTitle.equals(actualTitle)) {
            System.out.println("Page title validation successful.");
        } else {
            System.out.println("Page title validation failed.");
        }

        // Close the browser
        driver.quit();
    }
}
