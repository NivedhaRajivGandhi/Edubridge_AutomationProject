package basic_Functionalities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Parallel_Testing2 
{
	WebDriver driver;
	   @Test
	    public void Retrive() throws InterruptedException 
	   {
        // Launch Browser
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
        driver = new ChromeDriver();
                
        // Login
        driver.get("https://demo.guru99.com/insurance/v1/index.php");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.findElement(By.name("email")).sendKeys("nivi@gmail.com");
        Thread.sleep(1000);
        driver.findElement(By.id("password")).sendKeys("Admin123@");
        Thread.sleep(1000);
        driver.findElement(By.name("submit")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("ui-id-3")).click();
       
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.name("id")).sendKeys("35757");
		Thread.sleep(4000);
		driver.findElement(By.id("getquote")).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// Scroll to the bottom of the page smoothly
		js.executeScript("window.scrollBy(0, document.body.scrollHeight/0.5)");
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(4000);
		driver.findElement(By.cssSelector(".btn.btn-danger")).click();

		driver.close();


}
}
