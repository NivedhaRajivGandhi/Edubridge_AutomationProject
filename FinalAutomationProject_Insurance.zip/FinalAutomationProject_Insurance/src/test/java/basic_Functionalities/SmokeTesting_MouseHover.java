package basic_Functionalities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SmokeTesting_MouseHover 
{
    static WebDriver driver = null;


    public static void main(String[] args) throws Exception 
    {
        // Launch Browser
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
        driver = new ChromeDriver();
                
        // Login
        driver.get("https://demo.guru99.com/insurance/v1/index.php");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.findElement(By.name("email")).sendKeys("nivi@gmail.com");
        Thread.sleep(1000);
        driver.findElement(By.id("password")).sendKeys("Admin123@");
        Thread.sleep(1000);
        driver.findElement(By.name("submit")).click();
        Thread.sleep(1000);
        
     // Create a JavaScriptExecutor instance
        JavascriptExecutor js = (JavascriptExecutor) driver;
     // Scroll to the bottom of the page smoothly
        js.executeScript("window.scrollBy(0, document.body.scrollHeight/0.5)");

        // Mouse Hover
        Actions actions = new Actions(driver);
	
	     // Find all the elements within the menu
	     List<WebElement> elements = driver.findElements(By.xpath("//*[@id='menu']/li"));
	
	     // Get the size of the list
	     int size = elements.size();
	     System.out.println("Number of Modules: " + size);
	
	     // Loop through each element
	     for(int i = 1; i <= size; i++) 
	     {
	         // Wait
	         Thread.sleep(2000);
	
	         // Display the name of the module
	         System.out.println(driver.findElement(By.xpath("//*[@id='menu']/li[" + i + "]")));
	
	         // Perform Mouse Hover
	         actions.moveToElement(driver.findElement(By.xpath("//*[@id='menu']/li[" + i + "]"))).click().perform();
	
	         // Wait
	         Thread.sleep(2000);
	     }
     driver.close();
    }
}
