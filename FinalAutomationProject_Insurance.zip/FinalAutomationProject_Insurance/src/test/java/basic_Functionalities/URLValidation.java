package basic_Functionalities;

import org.testng.annotations.Test;
import pom_ap_PACKAGE.POM_Demoguru_Login;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class URLValidation 
{
    WebDriver driver;

    @Test
    public void URL_Validation() throws InterruptedException 
    {
        // Launch Browser
        System.setProperty("webdriver.chrome.driver","C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        // Open the page using POM
        POM_Demoguru_Login p = new POM_Demoguru_Login();
        p.openexactpage(driver);
        
        // Verify URL
        String expectedURL = "https://demo.guru99.com/insurance/v1/index.php";
        String actualURL = driver.getCurrentUrl();
        System.out.println("Actual URL:" + actualURL);

        if (actualURL.equals(expectedURL)) {
            System.out.println("Expected URL PASSED");
        } else {
            Assert.fail("URL Validation Fail: Actual URL is different from Expected URL");
        }
        
        // Close the browser
        driver.quit();
    }
}
