package ddt_DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom_ap_PACKAGE.POM_Demoguru_Login;

public class Insturance_DDT 
{

    public static void main(String[] args) throws Exception 
    {
        // STEP 1: Create an object to store the Excel file path
        FileInputStream file = new FileInputStream("C:\\Users\\ganes\\OneDrive\\Desktop\\AP.xlsx");

        // STEP 2: Create an object for the workbook
        XSSFWorkbook w = new XSSFWorkbook(file);

        // STEP 3: Create an object for the sheet ("DDT") using the workbook object
        XSSFSheet sheet = w.getSheet("DDT");

        // Launch the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ganes\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        // Create an object for POM class repository
        POM_Demoguru_Login p = new POM_Demoguru_Login();

        // Retrieve the number of rows in the sheet
        int size = sheet.getLastRowNum();
        System.out.println("Number of credentials: " + size);

        for (int i = 1; i <= size; i++) 
        {
            String username = sheet.getRow(i).getCell(0).getStringCellValue();
            String password = sheet.getRow(i).getCell(1).getStringCellValue();
            System.out.println(username + "\t\t" + password);

            // Handle invalid credentials exception (negative testing)
            try 
            {
                // Login
                p.openexactpage(driver);
                p.Loginddt(driver, username, password);
                p.logout(driver);
                System.out.println("Valid Credentials");
                System.out.println("");
                sheet.getRow(i).createCell(2).setCellValue("Valid Credentials");
           
            } 
            catch (Exception e) 
            {
                System.out.println("Invalid Credentials");
                System.out.println("");
                sheet.getRow(i).createCell(2).setCellValue("Invalid Credentials");
                
            }        
          }
        
        // Close the browser
        p.closeBrowser(driver);

        // Write the updated workbook to the file
        FileOutputStream out = new FileOutputStream("C:\\Users\\ganes\\OneDrive\\Desktop\\AP.xlsx");
        w.write(out);
        
        // Close the workbook and output stream
        w.close();
        out.close();
    }
}
