package main_Functionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class RunEntire_Project 
{
	WebDriver driver;

	@Test
	public void logout() throws Exception 
	{
		Retrive_Quotation r=new Retrive_Quotation();
		r.perform_retrive_quotation();
		
        driver.findElement(By.cssSelector("button[type='submit']")).click();
		driver.close();
		
	}
}
