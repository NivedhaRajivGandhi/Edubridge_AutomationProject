package main_Functionalities; // Package declaration

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Request_Quotation {
	WebDriver driver;

	@Test
	public WebDriver Req_Quotation() throws Exception {
		// Obtain WebDriver instance by updating profile
		Update_Profile l = new Update_Profile();
		driver = l.perform_update_profile();
		Thread.sleep(2000); // Wait for page load
		
		// Navigate to quotation section and fill out form
		driver.findElement(By.id("ui-id-2")).click(); // Navigate to quotation section
		selectOptionByValue("quotation_breakdowncover", "2"); // Select breakdown cover option
		driver.findElement(By.id("quotation_windscreenrepair_t")).click(); // Click windscreen repair option
		driver.findElement(By.id("quotation_incidents")).sendKeys("2331"); // Fill in incident count
		driver.findElement(By.id("quotation_vehicle_attributes_registration")).sendKeys("DL1AB1234"); // Fill in vehicle registration
		driver.findElement(By.id("quotation_vehicle_attributes_mileage")).sendKeys("20,000"); // Fill in mileage
		driver.findElement(By.id("quotation_vehicle_attributes_value")).sendKeys("692000"); // Fill in vehicle value
		selectOptionByValue("quotation_vehicle_attributes_parkinglocation", "Public place"); // Select parking location
		selectOptionByValue("quotation_vehicle_attributes_policystart_1i", "2024"); // Select policy start year
		selectOptionByValue("quotation_vehicle_attributes_policystart_2i", "3"); // Select policy start month
		selectOptionByValue("quotation_vehicle_attributes_policystart_3i", "23"); // Select policy start day
		driver.findElement(By.cssSelector("input.btn.btn-default")).click(); // Calculate premium
		Thread.sleep(2000); // Wait for calculation
		driver.findElement(By.cssSelector("input.btn.btn-success")).click(); // Save quotation
		Thread.sleep(10000); // Wait for saving
		driver.navigate().back();	// Navigate back
		Thread.sleep(2000); // Wait for page load
		driver.findElement(By.id("ui-id-2")).click(); // Navigate to quotation section again
		Thread.sleep(2000); // Wait for page load
		driver.findElement(By.id("resetquote")).click(); // Reset quotation form
		Thread.sleep(2000); // Wait for action completion
		//return driver; // Return WebDriver instance
		return driver;
	}

	// Method to select dropdown option by value
	private void selectOptionByValue(String elementId, String value) throws InterruptedException 
	{
		Select dropdown = new Select(driver.findElement(By.id(elementId))); // Initialize Select object
		Thread.sleep(1000); // Wait for element visibility
		dropdown.selectByValue(value); // Select option by value
		Thread.sleep(2000); // Wait for action completion
	}
}
