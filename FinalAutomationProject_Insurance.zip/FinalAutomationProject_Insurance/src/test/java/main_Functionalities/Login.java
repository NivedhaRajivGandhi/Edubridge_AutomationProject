package main_Functionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import basic_Functionalities.CrossBrowser_Testing;
import pom_ap_PACKAGE.POM_Demoguru_Login;

public class Login {
    WebDriver driver;

    @Test
    public WebDriver login() throws Exception {
        CrossBrowser_Testing ct = new CrossBrowser_Testing();
        driver = ct.WebDriver_selectBrowser();
        
        driver.get("https://demo.guru99.com/insurance/v1/index.php");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.findElement(By.name("email")).sendKeys("nivi@gmail.com");
        Thread.sleep(1000);
        driver.findElement(By.id("password")).sendKeys("Admin123@");
        Thread.sleep(1000);
        driver.findElement(By.name("submit")).click();
        Thread.sleep(1000);

        if (driver.getCurrentUrl().contains("header.php")) {
            System.out.println("Login Successful!");
            
        } else {
            POM_Demoguru_Login p = new POM_Demoguru_Login();
            p.handleRegistration(driver);

            if (driver.getCurrentUrl().contains("header.php")) {
                System.out.println("Registration Successful!");
                
            } else {
                System.out.println("Registration Failed!");
            }
            System.out.println("Login failed! Registration performed.");
        }
		return driver;
    }
}
