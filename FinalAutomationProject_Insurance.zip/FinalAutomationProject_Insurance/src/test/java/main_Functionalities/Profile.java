package main_Functionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pom_ap_PACKAGE.POM_Demoguru_Login;

public class Profile 
{
    WebDriver driver;

    @Test
    public WebDriver profilefunction() throws Exception 
    {
        // Create an instance of the Login_Using_Scanner_Dialogbox class
        Login l = new Login();

        // Call the login method to log in and assign the returned WebDriver instance to the driver variable
        driver = l.login();

        // Check if driver is not null
        if (driver != null) 
        {
            // Create an instance of the POM_Demoguru_Login class
            POM_Demoguru_Login p = new POM_Demoguru_Login();

            // Scroll using the scroll method from POM_Demoguru_Login class
            p.scroll(driver);

            // Add any other actions specific to the profile page
            Thread.sleep(2000); // Add explicit wait if needed
            driver.findElement(By.id("ui-id-4")).click();
            p.scroll(driver);
        }
        else 
        {
            // Handle the case when login fails
            System.out.println("Login failed! Cannot proceed to profile page.");
        }
       return driver;
    }
}