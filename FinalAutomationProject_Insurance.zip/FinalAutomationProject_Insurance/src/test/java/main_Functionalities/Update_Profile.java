package main_Functionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pom_ap_PACKAGE.POM_Demoguru_Login;

@Test
public class Update_Profile 
{
	WebDriver driver;

	public WebDriver perform_update_profile() throws Exception 
	{
		Profile p = new Profile();
		driver = p.profilefunction(); // Assign the returned WebDriver instance

		// Check if driver is not null
		if (driver != null) 
		{
			
			Thread.sleep(2000);
			POM_Demoguru_Login r=new POM_Demoguru_Login();
			r.handleRegistration(driver);
            r.scroll(driver);

            // Add any other actions specific to the profile page
            Thread.sleep(2000); // Add explicit wait if needed
            driver.findElement(By.id("ui-id-4")).click();
            r.scroll(driver);

		}
		else 
		{
			// Handle the case when login fails
			System.out.println("Login failed! Cannot update profile.");
		}
		return driver;
	}
}
