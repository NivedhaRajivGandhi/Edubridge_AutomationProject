 package main_Functionalities;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.time.Duration;

public class Retrive_Quotation {
	WebDriver driver;
	@Test
	public WebDriver perform_retrive_quotation() throws Exception 
	{
		Request_Quotation l = new Request_Quotation();
		driver =l.Req_Quotation();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		driver.findElement(By.id("ui-id-3")).click();
		//String identificationNumber = JOptionPane.showInputDialog("Enter identificationNumber");
		//driver.findElement(By.name("id")).sendKeys(identificationNumber);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.name("id")).sendKeys("");

		Thread.sleep(2000);
		driver.findElement(By.id("getquote")).click();
		driver.navigate().back();
		Thread.sleep(2000);

		return driver;
	}

}